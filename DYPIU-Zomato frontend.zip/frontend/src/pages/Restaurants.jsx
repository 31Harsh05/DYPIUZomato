import { useEffect, useState } from 'react';
import { fetchRestaurants } from '../lib/fetchRestaurants';
import { Link } from 'react-router-dom';

function Restaurants() {
  const [restaurants, setRestaurants] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchRestaurants()
      .then(setRestaurants)
      .catch(err => setError(err.message));
  }, []);

  if (error) return <p style={{ color: 'red' }}>❌ {error}</p>;
  if (restaurants.length === 0) return <p>Loading restaurants...</p>;

  return (
    <div style={{ padding: '2rem' }}>
      <h2>All Restaurants</h2>
      <ul>
        {restaurants.map((rest) => (
          <li key={rest.restaurant_id}>
            <strong>{rest.restaurant_name}</strong> — {rest.location}
            <br />
            <Link to={`/restaurants/${rest.restaurant_id}`}>View Menu 🍽</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Restaurants;
