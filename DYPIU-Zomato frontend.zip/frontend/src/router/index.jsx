import { createBrowserRouter } from 'react-router-dom';
import RootLayout from '../layouts/RootLayout';
import Home from '../pages/Home';
import Login from '../pages/Login';
import Register from '../pages/Register';
import Restaurants from '../pages/Restaurants';
import RestaurantMenu from '../pages/RestaurantMenu';
import Cart from '../pages/Cart';
import Payment from '../pages/Payment';
import OrderHistory from '../pages/OrderHistory';

const router = createBrowserRouter([
  {
    path: '/',
    element: <RootLayout />,
    children: [
      { index: true, element: <Home /> },
      { path: 'login', element: <Login /> },
      { path: 'register', element: <Register /> },
      { path: 'restaurants', element: <Restaurants /> },
       { path: 'restaurants/:restaurantId', element: <RestaurantMenu /> },
      { path: 'cart', element: <Cart /> },
      { path: 'payment', element: <Payment /> },
      { path: 'orders', element: <OrderHistory /> },
    ],
  },
]);

export default router;
