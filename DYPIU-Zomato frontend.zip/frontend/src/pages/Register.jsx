import { registerAction } from '../actions/authActions';
import { useState } from 'react';

function Register() {
  const [message, setMessage] = useState('');

  async function handleRegister(formData) {
    const result = await registerAction(formData);
    setMessage(result.message);

    if (result.success) {
      setTimeout(() => {
        window.location.href = '/login'; // redirect to login
      }, 1500);
    }
  }

  return (
    <div style={{ padding: '2rem' }}>
      <h2>Register</h2>
      <form action={handleRegister} method="post">
  <input type="text" name="username" placeholder="Username" required />
  <input type="email" name="email" placeholder="Email" required />
  <input type="password" name="password" placeholder="Password" required />
  <input type="text" name="firstName" placeholder="First Name" required />
  <input type="text" name="lastName" placeholder="Last Name" required />
  <input type="tel" name="mobile" placeholder="Mobile Number" required />
  <button type="submit">Register</button>
</form>


      <p>{message}</p>
    </div>
  );
}

export default Register;
