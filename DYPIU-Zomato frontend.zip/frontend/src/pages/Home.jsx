function Home() {
  return <h1 style={{ color: 'green' }}>🏠 Welcome to DYPIUZomato</h1>;
}
export default Home;
