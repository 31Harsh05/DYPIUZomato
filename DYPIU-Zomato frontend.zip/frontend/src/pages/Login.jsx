import { loginAction } from '../actions/authActions';
import { useState } from 'react';

function Login() {
  const [message, setMessage] = useState('');

  async function handleLogin(formData) {
    const result = await loginAction(formData);

    setMessage(result.message);
    if (result.success) {
      // You can store the user or token here
      localStorage.setItem('user', JSON.stringify(result.user));
      // Optional: navigate to restaurants
      window.location.href = '/restaurants';
    }
  }

  return (
    <div style={{ padding: '2rem' }}>
      <h2>Login</h2>
      <form action={handleLogin} method="post">
        <input name="email" type="email" placeholder="Email" required />
        <br />
        <input name="password" type="password" placeholder="Password" required />
        <br />
        <button type="submit">Login</button>
      </form>
      <p>{message}</p>
    </div>
  );
}

export default Login;
