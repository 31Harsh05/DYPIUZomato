export async function loginAction(formData) {
  const email = formData.get('email');
  const password = formData.get('password');

  try {
    const res = await fetch('http://localhost:5000/api/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    });

    const result = await res.json();

    if (!res.ok) {
      throw new Error(result.message || 'Login failed');
    }

    return { success: true, message: result.message, user: result.user };
  } catch (err) {
    return { success: false, message: err.message };
  }
}

export async function registerAction(formData) {
  const username = formData.get('username');
  const email = formData.get('email');
  const password = formData.get('password');
  const firstName = formData.get('firstName');
  const lastName = formData.get('lastName');
  const mobile = formData.get('mobile');

  try {
    const res = await fetch('http://localhost:5000/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, password, firstName, lastName, mobile }),
    });

    const result = await res.json();
    if (!res.ok) throw new Error(result.message || 'Registration failed');
    return { success: true, message: result.message };
  } catch (err) {
    return { success: false, message: err.message };
  }
}
