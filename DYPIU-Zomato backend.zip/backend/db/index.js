import mysql from 'mysql2/promise';

const db = await mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '3105',         
  database: 'DYPIUZomato', 
});

console.log('✅ MySQL Connected');

export default db;
