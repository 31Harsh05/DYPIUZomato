import { useCart } from '../context/CartContext';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Payment() {
  const { cart, clearCart } = useCart();
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const navigate = useNavigate();

  // Dynamically get logged-in user (replace this later with real logic)
  const user = JSON.parse(localStorage.getItem('user'));
  const customerId = user?.customer_id || 1;

  const restaurantId = cart.length ? cart[0].restaurant_id : null;
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handlePayment = async () => {
    // ✅ Frontend validation
    if (!customerId || !restaurantId || cart.length === 0) {
      alert('Missing required details to place order.');
      return;
    }

    console.log("Submitting order with:", {
      customerId,
      restaurantId,
      items: cart,
      paymentMethod,
    });

    const res = await fetch('http://localhost:5000/api/order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        customerId,
        restaurantId,
        items: cart,
        paymentMethod,
        deliveryPartnerId: 1,
      }),
    });

    const data = await res.json();

    if (data.success) {
      alert('✅ Order placed successfully!');
      clearCart();
      navigate('/orders');
    } else {
      alert('❌ Failed to place order: ' + data.message);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <h2>Checkout</h2>
      <p>Total: ₹{total}</p>
      <label>
        Payment Method:
        <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
          <option value="Cash">Cash</option>
          <option value="Card">Card</option>
          <option value="UPI">UPI</option>
        </select>
      </label>
      <br />
      <button onClick={handlePayment}>Confirm & Pay</button>
    </div>
  );
}

export default Payment;
