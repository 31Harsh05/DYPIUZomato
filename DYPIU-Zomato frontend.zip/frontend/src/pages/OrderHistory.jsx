import { useEffect, useState } from 'react';

function OrderHistory() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  // ✅ Get logged-in user
  const user = JSON.parse(localStorage.getItem('user'));
  const customerId = user?.customer_id;

  useEffect(() => {
    if (!customerId) {
      alert('You must be logged in to view orders.');
      return;
    }

    fetch(`http://localhost:5000/api/orders/${customerId}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setOrders(data.orders);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to fetch orders:", err);
        setLoading(false);
      });
  }, [customerId]);

  if (!customerId) return <p>Please log in to view your order history.</p>;
  if (loading) return <p>Loading order history...</p>;

  return (
    <div style={{ padding: '2rem' }}>
      <h2>Order History</h2>
      {orders.length === 0 ? (
        <p>No past orders found.</p>
      ) : (
        <ul>
          {orders.map((order) => (
            <li key={order.order_id}>
              <p>
                <strong>Order #{order.order_id}</strong> — ₹{order.total_amount}
              </p>
              <p>
                Restaurant: {order.restaurant_name} | {order.order_time} | {order.order_date}
              </p>
              <p>Payment Method: {order.payment_method}</p>
              <hr />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default OrderHistory;
