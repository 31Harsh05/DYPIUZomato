import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { fetchMenu } from '../lib/fetchMenu';
import { useCart } from '../context/CartContext';

function RestaurantMenu() {
  const { restaurantId } = useParams();
  const [menu, setMenu] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const { addToCart } = useCart();

  useEffect(() => {
    if (!restaurantId) return;

    fetchMenu(restaurantId)
      .then((data) => {
        setMenu(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, [restaurantId]);

  if (loading) return <p>Loading menu...</p>;
  if (error) return <p style={{ color: 'red' }}>{error}</p>;

  return (
    <div style={{ padding: '2rem' }}>
      <h2>Menu for Restaurant #{restaurantId}</h2>
      <ul>
        {menu.map((item) => (
          <li key={item.food_id}>
            <strong>{item.food_name}</strong> — ₹{item.price}
            <p>{item.description}</p>
            <button onClick={() => addToCart({ ...item, restaurant_id: parseInt(restaurantId) })}>
  Add to Cart 🛒
</button>

          </li>
        ))}
      </ul>
    </div>
  );
}

export default RestaurantMenu;
