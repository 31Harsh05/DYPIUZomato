import express from 'express';
import db from '../db/index.js';

const router = express.Router();

// POST /api/order
router.post('/order', async (req, res) => {
  const { customerId, items, paymentMethod, restaurantId, deliveryPartnerId } = req.body;

  try {
    // Calculate total amount
    let totalAmount = 0;
    for (const item of items) {
      totalAmount += item.price * item.quantity;
    }

    // Current date and time
    const now = new Date();
    const orderDate = now.toISOString().split('T')[0];
    const orderTime = now.toTimeString().split(' ')[0];

    // Insert into ORDERS
    const [orderResult] = await db.execute(
      `INSERT INTO ORDERS (
        order_time, order_date, total_amount, delivery_time,
        customer_id, id_number, restaurant_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        orderTime,
        orderDate,
        totalAmount,
        '30 mins', // example delivery time
        customerId,
        deliveryPartnerId || 1, // fallback partner ID
        restaurantId,
      ]
    );

    const orderId = orderResult.insertId;

    // Insert into PAYMENT
    await db.execute(
      `INSERT INTO PAYMENT (
        payment_method, amount, customer_id, order_id, restaurant_id
      ) VALUES (?, ?, ?, ?, ?)`,
      [paymentMethod, totalAmount, customerId, orderId, restaurantId]
    );

    res.json({ success: true, orderId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Order failed' });
  }
});

// GET /api/orders/:customerId
router.get('/orders/:customerId', async (req, res) => {
  const { customerId } = req.params;

  try {
    const [orders] = await db.execute(
      `SELECT 
         o.order_id, o.order_time, o.order_date, o.total_amount, o.delivery_time,
         r.restaurant_name, p.payment_method
       FROM ORDERS o
       JOIN RESTAURANT r ON o.restaurant_id = r.restaurant_id
       JOIN PAYMENT p ON o.order_id = p.order_id
       WHERE o.customer_id = ?
       ORDER BY o.order_id DESC`,
      [customerId]
    );

    res.json({ success: true, orders });
  } catch (err) {
    console.error(' Order History Error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch orders' });
  }
});

export default router;
