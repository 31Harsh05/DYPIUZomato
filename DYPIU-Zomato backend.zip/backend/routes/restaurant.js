import express from 'express';
import db from '../db/index.js';

const router = express.Router();

/// GET /api/restaurants
router.get('/restaurants', async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT restaurant_id, restaurant_name, location FROM RESTAURANT');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to fetch restaurants' });
  }
});

// GET /api/menu/:restaurantId
router.get('/menu/:restaurantId', async (req, res) => {
  const { restaurantId } = req.params;
  try {
    const [rows] = await db.execute(
      'SELECT food_id, food_name, price, description FROM MENU WHERE restaurant_id = ?',
      [restaurantId]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to fetch menu' });
  }
});

export default router;
