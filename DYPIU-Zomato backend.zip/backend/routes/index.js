import express from 'express';
import authRoutes from './auth.js';
import restaurantRoutes from './restaurant.js';
import orderRoutes from './order.js';

const router = express.Router();

router.use(authRoutes);        // /api/login
router.use(restaurantRoutes);  // /api/restaurants and /api/menu/:id
router.use(orderRoutes);       // /api/order

export default router;
