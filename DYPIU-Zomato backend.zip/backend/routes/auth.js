import express from 'express';
import db from '../db/index.js';

const router = express.Router();

// POST /api/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

console.log("📦 Received Body:", req.body);
console.log("📧 Email:", req.body.email);
console.log("🔑 Password:", req.body.password);

  //  Validate input
  if (!email || !password) {
    return res.status(400).json({
      success: false,
      status: 'error',
      message: 'Email and password are required',
    });
  }

  try {
    //  Query the database
    const [rows] = await db.execute(
      'SELECT * FROM CUSTOMER WHERE email_id = ? AND password = ?',
      [email, password]
    );

    //  Check if a match was found
    if (rows.length > 0) {
      return res.json({
        success: true,
        status: 'success',
        message: 'Login successful',
        user: rows[0],
      });
    } else {
      return res.status(401).json({
        success: false,
        status: 'error',
        message: 'Invalid credentials',
      });
    }
  } catch (err) {
    console.error(' Login Error:', err.message);
    return res.status(500).json({
      success: false,
      status: 'error',
      message: 'Internal server error',
    });
  }
});

export default router;

// POST /api/register
router.post('/register', async (req, res) => {
  const { username, email, password, firstName, lastName, mobile } = req.body;


  console.log("📝 Register Body:", req.body);

  // Validate input
  if (!email || !password) {
    return res.status(400).json({
      success: false,
      status: 'error',
      message: 'Email and password are required',
    });
  }

  try {
    // Check if email already exists
    const [existingUser] = await db.execute(
      'SELECT * FROM CUSTOMER WHERE email_id = ?',
      [email]
    );

    if (existingUser.length > 0) {
      return res.status(409).json({
        success: false,
        status: 'error',
        message: 'Email already registered',
      });
    }

    // Insert new user
    await db.execute(
  `INSERT INTO CUSTOMER (username, email_id, password, First_name, Last_name, mobile_no)
   VALUES (?, ?, ?, ?, ?, ?)`,
  [username, email, password, firstName, lastName, mobile]
);


    return res.status(201).json({
      success: true,
      status: 'success',
      message: 'Registration successful',
    });
  } catch (err) {
    console.error('Register Error:', err.message);
    return res.status(500).json({
      success: false,
      status: 'error',
      message: 'Internal server error',
    });
  }
});
