import { useCart } from '../context/CartContext';

function Cart() {
  const {
    cart,
    removeFromCart,
    clearCart,
    increaseQty,
    decreaseQty,
  } = useCart();

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div style={{ padding: '2rem' }}>
      <h2>Your Cart</h2>
      {cart.length === 0 ? (
        <p>🛒 Your cart is empty.</p>
      ) : (
        <div>
          <ul>
            {cart.map((item) => (
              <li key={item.food_id} style={{ marginBottom: '1rem' }}>
                <strong>{item.food_name}</strong> — ₹{item.price} × {item.quantity} = ₹{item.price * item.quantity}
                <br />
                <button onClick={() => decreaseQty(item.food_id)}>➖</button>
                <button onClick={() => increaseQty(item.food_id)}>➕</button>
                <button onClick={() => removeFromCart(item.food_id)}>❌ Remove</button>
              </li>
            ))}
          </ul>
          <h3>Total: ₹{total}</h3>
          <button onClick={clearCart}>Clear Cart</button>
        </div>
      )}
    </div>
  );
}

export default Cart;
